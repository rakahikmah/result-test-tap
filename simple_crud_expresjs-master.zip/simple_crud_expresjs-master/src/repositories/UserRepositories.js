const db = require('../config/database');

class UserRepository {
    async getAll() {
        const [rows] = await db.query("SELECT * FROM users");
        return rows;
    }

    async getById(id) {
        const [rows] = await db.query("SELECT * FROM users WHERE id = ?", [id]);
        return rows[0] || null;
    }

    async create(user) {
        const { name, email, age, bod } = user;
        const [result] = await db.query(
            "INSERT INTO users (name, email, age, bod) VALUES (?, ?, ?, ?)",
            [name, email, age, bod]
        );
        return { id: result.insertId, ...user };
    }

    async update(id, userData) {
        const { name, email, age, bod } = userData;
        await db.query(
            "UPDATE users SET name = ?, email = ?, age = ?, bod = ? WHERE id = ?",
            [name, email, age, bod, id]
        );
        return this.getById(id);
    }

    async delete(id) {
        const user = await this.getById(id);
        if (!user) return null;
        await db.query("DELETE FROM users WHERE id = ?", [id]);
        return user;
    }
}

module.exports = new UserRepository();

import GrafikPenduduk from './components/GrafikPenduduk';

function App() {
  return (
    <div className="container mt-5">
      <div className="row justify-content-center align-items-center min-vh-100">
        <div className="col-lg-12 col-md-12"> 
          <header className="text-center mb-4">
            <h1 className="display-5 fw-bold">Dashboard Kependudukan</h1>
            <p className="lead">Tren Pertumbuhan Penduduk Indonesia</p>
          </header>
          
          <main>
            <GrafikPenduduk />
          </main>

          <footer className="text-center mt-5 text-muted">
            <p>Sumber Data: World Bank</p>
          </footer>
        </div>
      </div>
    </div>
  );
}

export default App;
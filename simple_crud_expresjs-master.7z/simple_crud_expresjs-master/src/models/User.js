class User {
    constructor(id, name, email, age, bod) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.age = age;
        this.bod = bod;
    }
}

module.exports = User;

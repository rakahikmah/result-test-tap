const { UserRepositories } = require('../repositories');
const { User } = require('../models');

class UserService {
    async getAllUsers() {
        return await UserRepositories.getAll();
    }

    async getUserById(id) {
        return await UserRepositories.getById(id);
    }

    async createUser(name, email, age, bod) {
        const user = new User(null, name, email, age, bod);
        return await UserRepositories.create(user);
    }

    async updateUser(id, userData) {
        return await UserRepositories.update(id, userData);
    }

    async deleteUser(id) {
        return await UserRepositories.delete(id);
    }
}

module.exports = new UserService();

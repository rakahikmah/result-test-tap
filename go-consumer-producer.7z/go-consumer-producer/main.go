package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/segmentio/kafka-go"
)

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func runProducer(ctx context.Context, broker, topic string, count int) {
	w := kafka.NewWriter(kafka.WriterConfig{
		Brokers:  []string{broker},
		Topic:    topic,
		Balancer: &kafka.LeastBytes{}, // lebih efisien
	})
	defer w.Close()

	for i := 1; i <= count; i++ {
		select {
		case <-ctx.Done():
			log.Println("[producer] stopped by signal")
			return
		default:
			msg := kafka.Message{
				Key:   []byte(fmt.Sprintf("key-%d", i)),
				Value: []byte(fmt.Sprintf("hello-%d at %s", i, time.Now().Format(time.RFC3339))),
			}
			if err := w.WriteMessages(ctx, msg); err != nil {
				log.Fatal("failed to write messages:", err)
			}
			log.Printf("[producer] sent message: %s\n", msg.Value)
			time.Sleep(time.Second)
		}
	}
	log.Println("[producer] finished sending")
}

func runConsumer(ctx context.Context, broker, topic, group string) {
	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers:     []string{broker},
		GroupID:     group,
		Topic:       topic,
		StartOffset: kafka.FirstOffset, 
	})
	defer r.Close()

	log.Println("[consumer] waiting for messages...")
	for {
		select {
		case <-ctx.Done():
			log.Println("[consumer] stopped by signal")
			return
		default:
			m, err := r.ReadMessage(ctx)
			if err != nil {
				log.Fatal("failed to read message:", err)
			}
			log.Printf("[consumer] received: key=%s value=%s\n", string(m.Key), string(m.Value))
		}
	}
}

func main() {
	mode := getEnv("MODE", "producer")
	broker := getEnv("BROKER", "localhost:19092")

	topic := getEnv("TOPIC", "test-topic")
	group := getEnv("GROUP_ID", "demo-group")
	countStr := getEnv("MSG_COUNT", "5")
	count, _ := strconv.Atoi(countStr)

	
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigChan
		cancel()
	}()

	if mode == "producer" {
		runProducer(ctx, broker, topic, count)
	} else {
		runConsumer(ctx, broker, topic, group)
	}
}

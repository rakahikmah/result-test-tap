import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement, 
  LineElement,  
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2'; 

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const GrafikPenduduk = () => {
  const [chartData, setChartData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Tren Pertumbuhan Penduduk Indonesia (Data dari World Bank)',
        font: {
          size: 18,
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: function(value, index, values) {
            return (value / 1000000) + ' Juta';
          }
        }
      }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const apiUrl = 'https://api.worldbank.org/v2/country/ID/indicator/SP.POP.TOTL?format=json';
        const response = await fetch(apiUrl);
        const result = await response.json();

        if (result && result[1]) {
          const filteredData = result[1]
            .filter(item => item.value !== null && parseInt(item.date) >= 2010);
          
          const reversedData = filteredData.reverse();

          const processedData = {
            labels: reversedData.map(item => item.date), 
            datasets: [
              {
                label: 'Total Populasi',
                data: reversedData.map(item => item.value), 
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
              },
            ],
          };
          setChartData(processedData);
        }

      } catch (error) {
        console.error("Gagal mengambil data dari World Bank:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="card shadow-sm text-center p-5">
        <p>Mengambil data dari World Bank API...</p>
        <div className="spinner-border text-danger" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (!chartData) {
    return <div className="card shadow-sm text-center p-5"><p>Gagal memuat data.</p></div>;
  }
  
  return (
    <div className="card shadow-sm">
      <div className="card-body">
        <Line options={options} data={chartData} />
      </div>
    </div>
  );
};

export default GrafikPenduduk;